"""
NED scoring: given a ground truth and tool output, compute a NedResult.

Both sides may be **kern or MusicXML; the format is detected independently per side
(_is_xml), so datasets that publish symbolic ground truth only as MusicXML - e.g. ossq -
are scored without a lossy conversion to kern first.

Supports two scoring backends:
  - Native token-based comparison (fast, kern-specific component breakdown)
  - musicdiff structural comparison (slower, more robust cross-format alignment)

Public API: compute_ned, NedResult, TokenEvent
"""

import contextlib
import copy
import difflib
import io
import itertools
import os
import tempfile
import xml.etree.ElementTree as ET
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypedDict

import editdistance

from homr.circle_of_fifths import strip_naturals
from homr.transformer.vocabulary import EncodedSymbol, empty, nonote, sort_token_chords
from training.omr_datasets.humdrum_kern_parser import convert_kern_to_parts
from training.omr_datasets.music_xml_parser import music_xml_file_to_tokens

if TYPE_CHECKING:
    import music21 as m21


@dataclass
class NedResult:
    ned: float
    distance: int
    kern_len: int
    xml_len: int
    rhythm_ned: float
    pitch_ned: float
    lift_ned: float
    articulation_ned: float
    slur_ned: float


class TokenEvent(TypedDict):
    staff: str
    event_type: str  # 'match' | 'delete' | 'insert' | 'substitute'
    exp_rhythm: str | None
    exp_pitch: str | None
    exp_lift: str | None
    exp_articulation: str | None
    exp_slur: str | None
    act_rhythm: str | None
    act_pitch: str | None
    act_lift: str | None
    act_articulation: str | None
    act_slur: str | None


# ---------------------------------------------------------------------------
# Known ground-truth reliability exceptions (dataset-specific, opt-in only)
# ---------------------------------------------------------------------------

# btrkeks/polish-scores' kern transcriptions do not reliably encode SOME articulation
# marks, even on pages where the source engraving has them on nearly every note.
# Confirmed by an audit of all 112 samples (grep each kern for every articulation
# character humdrum_kern_parser.py recognizes):
#   staccato ('), staccatissimo (`), turn (S or $): ZERO occurrences in ALL 112 samples
#   accent (^), arpeggiate (:), fermata (;), trill/mordent (t/T/m/M): present normally
#     (e.g. accent: 377 occurrences across 96/112 samples) - these are NOT excluded
# Concrete, independently-checkable proof for staccato specifically: sample 79
# ("Gavotte", Jules Zarembski Op. 29) shows a staccato dot under/over nearly every
# single note in both staves throughout the whole page - see
# datasets/polish-scores/79.png - yet its kern transcription
# (datasets/polish-scores/79.krn) contains zero staccato markers ('):
#   python -c "print(open('datasets/polish-scores/79.krn').read().count(chr(39)))"   # -> 0
# Scoring these specific marks against ground truth like this measures the dataset's own
# transcription completeness, not tool accuracy - staccato hallucination was the single
# largest confusion pair in the whole polish-scores benchmark (1521 occurrences) before
# this exclusion existed. Accent, despite also being a large confusion pair, is NOT
# included here: the audit shows it genuinely is encoded in 86% of samples, so its
# hallucination rate is real signal about tool accuracy, not a ground-truth artifact.
#
# This is a btrkeks/polish-scores transcription artifact, not a property of the underlying
# scores/edition: the alternative HuggingFace dataset PRAIG/polish-scores covers the same
# scores and does reliably encode these marks. We still use btrkeks/polish-scores because
# it ships plain **kern directly, while PRAIG/polish-scores uses **ekern and requires the
# kernpy package to convert to **kern first - kernpy pins a antlr4-python3-runtime version
# that hard-conflicts with omegaconf (a transitive dependency of rapidocr, used in homr's
# live title-detection pipeline). So the transcription gap is accepted as the cost of
# avoiding that dependency conflict, not because a cleaner-ground-truth dataset is
# unavailable.
#
# This must stay opt-in: every scoring entry point below defaults
# ignore_unreliable_articulation to False, and only validation/polish-scores.py ever
# passes True. Other datasets (e.g. smb) have not been audited for the same problem and
# must not silently inherit this exception just because they share this scoring code.

# Only these specific components are unreliable in this dataset's ground truth (see
# audit above) - NOT the whole articulation field, which also carries accent, arpeggiate,
# fermata, trill, mordent etc. that ARE reliably encoded and must keep contributing to
# the score.
_UNRELIABLE_ARTICULATION_COMPONENTS = frozenset({"staccato", "staccatissimo", "turn"})


def _without_unreliable_articulation(articulation: str) -> str:
    """Removes only the unreliable components from a (possibly compound,
    underscore-joined) articulation value, e.g. "accent_staccato" -> "accent" - accent
    must survive since it is reliably encoded (see audit above), only the co-occurring
    staccato mark is dropped. nonote (".") and empty ("_") pass through unchanged."""
    if articulation in (nonote, empty):
        return articulation
    kept = [c for c in articulation.split("_") if c not in _UNRELIABLE_ARTICULATION_COMPONENTS]
    return "_".join(kept) if kept else empty


def _strip_articulation_from_parts(
    parts: list[list[EncodedSymbol]],
) -> list[list[EncodedSymbol]]:
    """Native-path counterpart to _strip_articulation_from_score below: rewrites
    articulation on a copy of every symbol so the unreliable components can never
    contribute to the diff, without touching rhythm/pitch/lift/slur/position or any
    other (reliable) articulation component."""
    result = []
    for part in parts:
        new_part = []
        for s in part:
            cleared = copy.copy(s)
            cleared.articulation = _without_unreliable_articulation(s.articulation)
            new_part.append(cleared)
        result.append(new_part)
    return result


def _strip_articulation_from_score(score: "m21.stream.Score") -> None:
    """musicdiff-path counterpart to _strip_articulation_from_parts above: mutates the
    music21 Score in place, removing only Staccato/Staccatissimo articulations and
    Turn/InvertedTurn expressions - the same narrow set as the native path, leaving
    accent, fermata, trill, mordent, etc. untouched."""
    import music21.articulations as m21_articulations  # noqa: PLC0415
    import music21.expressions as m21_expressions  # noqa: PLC0415

    unreliable_articulations = (m21_articulations.Staccato, m21_articulations.Staccatissimo)
    unreliable_expressions = (m21_expressions.Turn, m21_expressions.InvertedTurn)
    for n in score.recurse().notes:
        n.articulations = [
            a for a in n.articulations if not isinstance(a, unreliable_articulations)
        ]
        n.expressions = [e for e in n.expressions if not isinstance(e, unreliable_expressions)]


# ---------------------------------------------------------------------------
# Native token-based scoring
# ---------------------------------------------------------------------------


def _strip_position(symbols: list[EncodedSymbol]) -> list[EncodedSymbol]:
    return [EncodedSymbol(s.rhythm, s.pitch, s.lift, s.articulation, s.slur) for s in symbols]


def _flatten_part(measures: Sequence[Sequence[EncodedSymbol]]) -> list[EncodedSymbol]:
    flat = [s for measure in measures for s in measure]
    return [t for chord in sort_token_chords(flat) for t in chord]


def _component_dist(a: list[EncodedSymbol], b: list[EncodedSymbol], field: str) -> int:
    return editdistance.eval([getattr(s, field) for s in a], [getattr(s, field) for s in b])


def _split_grand_staff_part(part: ET.Element) -> list[ET.Element]:
    """
    Split a single <part> with <staves>2</staves> into two single-staff <part>
    elements. Returns [part] unchanged if it isn't a 2-staff grand staff (this
    also covers the (currently unseen) 3+-staff case: splitting would silently
    drop any staff beyond the second, so we leave those parts alone rather
    than guess).
    """
    staves_el = part.find(".//staves")
    if staves_el is None or int(staves_el.text or "1") != 2:
        return [part]

    def _staff_num(el: ET.Element) -> int:
        s = el.find("staff")
        return int(s.text) if s is not None and s.text else 0

    # Build two lists of measure elements, one per staff.
    split: list[list[ET.Element]] = [[], []]
    for measure in part.findall("measure"):
        for idx in range(2):
            split[idx].append(ET.Element("measure", measure.attrib))

        for child in measure:
            tag = child.tag

            if tag in ("backup", "forward"):
                continue  # timing reset between staves; not needed in split parts

            if tag == "note":
                s = _staff_num(child) - 1
                if 0 <= s < 2:
                    split[s][-1].append(child)
                continue

            if tag == "direction":
                s = _staff_num(child) - 1
                if 0 <= s < 2:
                    split[s][-1].append(child)
                else:
                    split[0][-1].append(child)
                    split[1][-1].append(copy.deepcopy(child))
                continue

            if tag == "attributes":
                attrs: list[ET.Element] = [ET.Element("attributes"), ET.Element("attributes")]
                for ac in child:
                    if ac.tag in ("staves", "part-symbol"):
                        continue
                    if ac.tag in ("clef", "staff-details"):
                        num = int(ac.get("number", "1")) - 1
                        if 0 <= num < 2:
                            el = copy.deepcopy(ac)
                            el.attrib.pop("number", None)
                            attrs[num].append(el)
                        continue
                    attrs[0].append(ac)
                    attrs[1].append(copy.deepcopy(ac))
                for idx, attr_el in enumerate(attrs):
                    if len(attr_el):
                        split[idx][-1].append(attr_el)
                continue

            # barline, print, sound, ... -> both parts
            split[0][-1].append(child)
            split[1][-1].append(copy.deepcopy(child))

    result = []
    for measures in split:
        p = ET.Element("part")
        for m in measures:
            p.append(m)
        result.append(p)
    return result


def _split_grand_staff(xml_text: str) -> str:
    """
    Split every <part> that has <staves>2</staves> into two single-staff
    <part> elements, in place, keeping the relative order of the other parts.

    Tools like homr output a piano grand staff as one <Part> with
    <staves>2</staves> and each note tagged <staff>1</staff> or
    <staff>2</staff>. music_xml_file_to_tokens treats a part as a single
    voice, so an unsplit grand staff dumps both staves into one token stream
    -- inflating NED massively against a kern ground truth that has the
    staves as separate spines. This isn't limited to piano-only scores (a
    single <part> document): the same problem occurs whenever a grand staff
    is combined with other parts, e.g. a solo voice plus piano accompaniment,
    so we split every matching part rather than only a lone one.
    """
    try:
        root = ET.fromstring(xml_text)  # noqa: S314
    except ET.ParseError:
        return xml_text

    parts = root.findall("part")
    final_parts = [split for part in parts for split in _split_grand_staff_part(part)]
    if len(final_parts) == len(parts):
        return xml_text  # nothing was split

    new_root = ET.Element(root.tag, root.attrib)
    for child in root:
        if child.tag not in ("part-list", "part"):
            new_root.append(copy.deepcopy(child))

    part_list = ET.SubElement(new_root, "part-list")
    for index, final_part in enumerate(final_parts):
        part_id = f"P{index + 1}"
        final_part.set("id", part_id)
        score_part = ET.SubElement(part_list, "score-part", id=part_id)
        ET.SubElement(score_part, "part-name").text = part_id
        new_root.append(final_part)

    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(new_root, encoding="unicode")


def _kern_parts(kern_text: str, kern_parser: str) -> list[list[EncodedSymbol]]:
    """Return per-part token lists using the selected kern parser."""
    if kern_parser == "music21":
        from training.omr_datasets.music21_kern_parser import (  # noqa: PLC0415
            convert_kern_to_parts_music21,
        )

        return convert_kern_to_parts_music21(kern_text.splitlines())
    return convert_kern_to_parts(kern_text.splitlines())  # "native"


def _xml_parts_from_text(xml_text: str, xml_parser: str) -> list[list[EncodedSymbol]]:
    """Return flat per-part token lists using the selected XML parser."""
    if xml_parser == "music21":
        from training.omr_datasets.music21_xml_parser import (  # noqa: PLC0415
            convert_xml_to_parts_music21,
        )

        return convert_xml_to_parts_music21(xml_text)
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".musicxml", delete=False, encoding="utf-8"
    ) as f:
        f.write(xml_text)
        xml_path = f.name
    try:
        xml_voices = music_xml_file_to_tokens(xml_path)
    finally:
        os.remove(xml_path)
    return [_flatten_part(p) for p in xml_voices]


def _is_xml(text: str) -> bool:
    stripped = text.lstrip()
    return stripped.startswith("<?xml") or "<score-partwise" in stripped[:500]


_ATTRIBUTE_KINDS = ("clef", "keySignature", "timeSignature")


def _collapse_repeated_attributes(part: list[EncodedSymbol]) -> list[EncodedSymbol]:
    """Keep only attribute tokens that change the running clef/key/meter.

    Engraving restates the clef and key at the start of every system, and a page-level
    reference built from per-system sources carries every one of those restatements.
    homr reports the musical state instead: one clef per part, then changes only. Both
    encode the same page, so scoring them against each other measures the convention,
    not the recognition - on OSSQ quartet pages the restatements were 40% of all
    non-matching tokens, roughly doubling the reported NED.

    Collapsing both sides removes that. It cannot hide a real error: a clef or key homr
    got wrong is a change on its side, a change the reference does not have, and
    survives. Only exact repeats of the value already in force are dropped.

    This is opt-in per dataset. The single-system benchmarks have at most one system per
    sample, so it would be a no-op there, and enabling it globally would silently change
    their published numbers.
    """
    active: dict[str, str] = {}
    result: list[EncodedSymbol] = []
    for symbol in part:
        kind = next((k for k in _ATTRIBUTE_KINDS if symbol.rhythm.startswith(k)), None)
        if kind is None:
            result.append(symbol)
        elif active.get(kind) != symbol.rhythm:
            active[kind] = symbol.rhythm
            result.append(symbol)
    return result


def _side_parts(text: str, kern_parser: str, xml_parser: str) -> list[list[EncodedSymbol]]:
    """Parse one side of the comparison (MusicXML or **kern) into per-part token lists.

    The format is auto-detected: MusicXML is parsed with xml_parser after grand-staff
    splitting, **kern directly with kern_parser - no intermediate kern->XML conversion.

    Both the ground truth and the tool output go through this same function, which is
    what makes a MusicXML ground truth sound (see _parse_output). A dataset whose
    ground truth is MusicXML rather than kern is then normalised by exactly the same
    steps as MusicXML tool output - _split_grand_staff, strip_naturals,
    _strip_position - so any artefact of the XML tokeniser appears identically on both
    sides and cancels out of the edit distance instead of being charged to the tool as
    a recognition error. Mixing the two (kern-parsed reference against XML-parsed
    prediction) is fine because the two parsers target the same EncodedSymbol
    vocabulary, but it does not have that cancellation property.
    """
    if _is_xml(text):
        xml_text = _split_grand_staff(text)
        raw = _xml_parts_from_text(xml_text, xml_parser)
        return [_strip_position(strip_naturals(p)) for p in raw]
    raw = _kern_parts(text, kern_parser)
    return [_strip_position([t for chord in sort_token_chords(p) for t in chord]) for p in raw]


def _parse_output(
    gt_text: str,
    raw_output: str,
    kern_parser: str = "native",
    xml_parser: str = "native",
    ignore_unreliable_articulation: bool = False,
    collapse_repeated_attributes: bool = False,
) -> tuple[list[list[EncodedSymbol]], list[list[EncodedSymbol]]]:
    """Parse ground truth and tool raw output into aligned per-part token lists.

    gt_text may be **kern (smb, polish-scores) or MusicXML (ossq) - the format is
    detected per side, so a dataset that only publishes symbolic ground truth as
    MusicXML needs no lossy conversion to kern first.

    ignore_unreliable_articulation: see "Known ground-truth reliability exceptions"
    above - opt-in only, set by callers benchmarking datasets with confirmed-unreliable
    articulation ground truth.
    collapse_repeated_attributes: see _collapse_repeated_attributes - opt-in only, for
    multi-system samples whose reference restates clef/key at every system.
    """
    gt_parts = _side_parts(gt_text, kern_parser, xml_parser)
    pred_parts = _side_parts(raw_output, kern_parser, xml_parser)
    if ignore_unreliable_articulation:
        gt_parts = _strip_articulation_from_parts(gt_parts)
        pred_parts = _strip_articulation_from_parts(pred_parts)
    if collapse_repeated_attributes:
        gt_parts = [_collapse_repeated_attributes(p) for p in gt_parts]
        pred_parts = [_collapse_repeated_attributes(p) for p in pred_parts]
    return gt_parts, pred_parts


# Brute-force exact assignment is only used up to this many parts (8! = 40320
# permutations, each a handful of editdistance.eval calls - a few tens of ms
# at most). Real scores in these datasets top out around quartets (4 parts);
# this is a generous margin above that, not a tuned/observed limit.
_MAX_PARTS_FOR_EXACT_MATCHING = 8


def _greedy_part_permutation(cost: list[list[int]]) -> list[int]:
    """Fallback for _best_part_permutation when there are too many parts to brute-force:
    repeatedly take the cheapest remaining (kern-index, xml-index) pair. Not guaranteed
    optimal, but reasonable, and only reached for part counts not observed in practice.
    """
    n = len(cost)
    remaining_rows = set(range(n))
    remaining_cols = set(range(n))
    perm = [-1] * n
    pairs = sorted((cost[i][j], i, j) for i in range(n) for j in range(n))
    for _, i, j in pairs:
        if i in remaining_rows and j in remaining_cols:
            perm[i] = j
            remaining_rows.discard(i)
            remaining_cols.discard(j)
    return perm


def _best_part_permutation(cost: list[list[int]]) -> list[int]:
    """Returns perm such that pairing row i with column perm[i] minimizes total cost."""
    n = len(cost)
    if n <= 1:
        return list(range(n))
    if n > _MAX_PARTS_FOR_EXACT_MATCHING:
        return _greedy_part_permutation(cost)
    best_perm = list(range(n))
    best_total = sum(cost[i][best_perm[i]] for i in range(n))
    for perm in itertools.permutations(range(n)):
        total = sum(cost[i][j] for i, j in enumerate(perm))
        if total < best_total:
            best_total = total
            best_perm = list(perm)
    return best_perm


def _align_parts(
    kern_parts: list[list[EncodedSymbol]],
    xml_parts: list[list[EncodedSymbol]],
) -> tuple[list[list[EncodedSymbol]], list[list[EncodedSymbol]]]:
    """
    Reorders xml_parts (after padding both lists to equal length with empty parts as
    needed) so that xml_parts[i] is the best content match for kern_parts[i], rather than
    assuming the two already agree on part order.

    Kern's spine order and a tool's part order do not always follow the same convention -
    e.g. a kern file can encode a vocal-plus-piano piece as [bass, treble, treble], while
    homr's split-grand-staff output (see _split_grand_staff) lists [vocal, piano-treble,
    piano-bass] for the same piece - a near-exact reversal despite every part having a
    real, correct match. Aligning purely by position would compare kern's bass against
    homr's vocal part, wildly inflating both the aggregate NED and any per-part
    diagnostics, even though the transcription itself may be perfectly fine. Matching by
    minimum total edit distance (an assignment problem, solved exactly for the realistic
    part counts in these datasets - see _best_part_permutation) finds the correct
    correspondence regardless of what order either side happens to list parts in.
    """
    n = max(len(kern_parts), len(xml_parts), 1)
    kern_padded = [kern_parts[i] if i < len(kern_parts) else [] for i in range(n)]
    xml_padded = [xml_parts[i] if i < len(xml_parts) else [] for i in range(n)]
    cost = [[editdistance.eval(k, x) for x in xml_padded] for k in kern_padded]
    perm = _best_part_permutation(cost)
    return kern_padded, [xml_padded[j] for j in perm]


def _ned_from_parts(
    kern_parts: list[list[EncodedSymbol]],
    xml_parts: list[list[EncodedSymbol]],
) -> NedResult:
    kern_parts, xml_parts = _align_parts(kern_parts, xml_parts)
    n = len(kern_parts)

    total_dist = sum(editdistance.eval(kern_parts[i], xml_parts[i]) for i in range(n))
    kern_len = sum(len(k) for k in kern_parts)
    xml_len = sum(len(x) for x in xml_parts)
    denominator = max(kern_len + xml_len, 1)

    def _cned(field: str) -> float:
        return (
            sum(_component_dist(kern_parts[i], xml_parts[i], field) for i in range(n)) / denominator
        )

    return NedResult(
        ned=total_dist / denominator,
        distance=total_dist,
        kern_len=kern_len,
        xml_len=xml_len,
        rhythm_ned=_cned("rhythm"),
        pitch_ned=_cned("pitch"),
        lift_ned=_cned("lift"),
        articulation_ned=_cned("articulation"),
        slur_ned=_cned("slur"),
    )


def _part_staff_name(i: int, n: int) -> str:
    if n == 2:
        return "upper" if i == 0 else "lower"
    return f"part_{i}"


def _events_for_parts(
    kern_parts: list[list[EncodedSymbol]],
    xml_parts: list[list[EncodedSymbol]],
) -> list[TokenEvent]:
    kern_parts, xml_parts = _align_parts(kern_parts, xml_parts)
    n = len(kern_parts)
    events: list[TokenEvent] = []
    for i in range(n):
        events.extend(_alignment_events(kern_parts[i], xml_parts[i], _part_staff_name(i, n)))
    return events


def _make_event(
    staff: str,
    event_type: str,
    exp: EncodedSymbol | None,
    act: EncodedSymbol | None,
) -> TokenEvent:
    return TokenEvent(
        staff=staff,
        event_type=event_type,
        exp_rhythm=exp.rhythm if exp is not None else None,
        exp_pitch=exp.pitch if exp is not None else None,
        exp_lift=exp.lift if exp is not None else None,
        exp_articulation=exp.articulation if exp is not None else None,
        exp_slur=exp.slur if exp is not None else None,
        act_rhythm=act.rhythm if act is not None else None,
        act_pitch=act.pitch if act is not None else None,
        act_lift=act.lift if act is not None else None,
        act_articulation=act.articulation if act is not None else None,
        act_slur=act.slur if act is not None else None,
    )


def _alignment_events(
    expected: list[EncodedSymbol],
    actual: list[EncodedSymbol],
    staff: str,
) -> list[TokenEvent]:
    matcher = difflib.SequenceMatcher(None, expected, actual, autojunk=False)
    events: list[TokenEvent] = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                events.append(_make_event(staff, "match", expected[i1 + k], actual[j1 + k]))
        elif tag == "delete":
            for k in range(i2 - i1):
                events.append(_make_event(staff, "delete", expected[i1 + k], None))
        elif tag == "insert":
            for k in range(j2 - j1):
                events.append(_make_event(staff, "insert", None, actual[j1 + k]))
        elif tag == "replace":
            n_exp = i2 - i1
            n_act = j2 - j1
            n_sub = min(n_exp, n_act)
            for k in range(n_sub):
                events.append(_make_event(staff, "substitute", expected[i1 + k], actual[j1 + k]))
            for k in range(n_sub, n_exp):
                events.append(_make_event(staff, "delete", expected[i1 + k], None))
            for k in range(n_sub, n_act):
                events.append(_make_event(staff, "insert", None, actual[j1 + k]))
    return events


def compute_ned(
    gt_text: str,
    raw_output: str,
    ignore_unreliable_articulation: bool = False,
    collapse_repeated_attributes: bool = False,
) -> NedResult:
    """Compute OMR-NED between ground truth and tool output.

    Both sides may be MusicXML or **kern; each format is detected independently.

    ignore_unreliable_articulation: see "Known ground-truth reliability exceptions" above.
    collapse_repeated_attributes: see _collapse_repeated_attributes.
    """
    gt_parts, pred_parts = _parse_output(
        gt_text,
        raw_output,
        ignore_unreliable_articulation=ignore_unreliable_articulation,
        collapse_repeated_attributes=collapse_repeated_attributes,
    )
    return _ned_from_parts(gt_parts, pred_parts)


# ---------------------------------------------------------------------------
# musicdiff-based scoring
# ---------------------------------------------------------------------------


def _musicdiff_register_once() -> None:
    """Register converter21 and apply musicdiff memoizer performance patch (idempotent)."""
    from types import SimpleNamespace  # noqa: PLC0415

    import converter21  # noqa: PLC0415
    import musicdiff.comparison as _md_cmp  # noqa: PLC0415

    converter21.register()

    # Every memoizer cache hit calls copy.deepcopy on the (ops_list, edit_distance) result,
    # recursively cloning potentially large op lists on each hit. Replace with a shallow copy
    # since ops are never mutated after creation. Technique from transcoda/evaluation/omr_ned.py.
    current_deepcopy = _md_cmp.copy.deepcopy  # type: ignore[attr-defined]
    if not getattr(current_deepcopy, "_homr_fast_memo_copy", False):
        _orig = current_deepcopy

        def _fast_deepcopy(value: object, memo: object = None) -> object:
            if isinstance(value, tuple) and len(value) == 2 and isinstance(value[0], list):
                return (list(value[0]), value[1])
            return _orig(value, memo)

        _fast_deepcopy._homr_fast_memo_copy = True  # type: ignore[attr-defined]
        _md_cmp.copy = SimpleNamespace(  # type: ignore[attr-defined,assignment]
            copy=_md_cmp.copy.copy,  # type: ignore[attr-defined]
            deepcopy=_fast_deepcopy,
        )


def _musicdiff_parse_xml_text(xml_text: str) -> object:
    """Parse MusicXML text into a music21 object via a temp file (music21 needs a path
    to pick the MusicXML reader reliably)."""
    import music21 as m21  # noqa: PLC0415

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".musicxml", delete=False, encoding="utf-8"
    ) as f:
        f.write(xml_text)
        path = f.name
    try:
        return m21.converter.parse(path, forceSource=True)
    finally:
        os.remove(path)


def _musicdiff_parse_scores(
    gt_text: str, raw_output: str, ignore_unreliable_articulation: bool = False
) -> tuple:
    """Parse ground truth and tool output into music21 Score objects.

    Either side may be MusicXML or **kern; the format is detected per side, so this
    mode supports MusicXML-ground-truth datasets (ossq) as well as kern ones.

    For kern predictions, acceptSyntaxErrors=True lets converter21 repair malformed
    measure durations (e.g. notes that don't fill a bar) rather than failing outright.
    Each repaired error is counted as an additional edit-distance unit via
    AnnScore.num_syntax_errors_fixed, so they are penalised without completely
    breaking the alignment. It is deliberately NOT applied to the ground truth: a
    reference that does not parse is a dataset bug that should surface, not be
    silently repaired and then charged to the tool.

    ignore_unreliable_articulation: see "Known ground-truth reliability exceptions" above.
    """
    import music21 as m21  # noqa: PLC0415

    if _is_xml(gt_text):
        gt_raw = _musicdiff_parse_xml_text(gt_text)
    else:
        with contextlib.redirect_stderr(io.StringIO()):
            gt_raw = m21.converter.parse(gt_text, format="humdrum")
    if isinstance(gt_raw, m21.stream.Opus):
        gt_raw = gt_raw.scores[0] if gt_raw.scores else m21.stream.Score()
    gt_score: m21.stream.Score = (
        gt_raw if isinstance(gt_raw, m21.stream.Score) else m21.stream.Score()
    )

    if _is_xml(raw_output):
        pred_raw = _musicdiff_parse_xml_text(raw_output)
    else:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".krn", delete=False, encoding="utf-8"
        ) as f:
            f.write(raw_output)
            pred_path = f.name
        try:
            with contextlib.redirect_stderr(io.StringIO()):
                pred_raw = m21.converter.parse(pred_path, forceSource=True, acceptSyntaxErrors=True)
        finally:
            os.remove(pred_path)

    if isinstance(pred_raw, m21.stream.Opus):
        pred_raw = pred_raw.scores[0] if pred_raw.scores else m21.stream.Score()
    pred_score: m21.stream.Score = (
        pred_raw if isinstance(pred_raw, m21.stream.Score) else m21.stream.Score()
    )
    if ignore_unreliable_articulation:
        _strip_articulation_from_score(gt_score)
        _strip_articulation_from_score(pred_score)
    return gt_score, pred_score


def _musicdiff_ned_for_sample(
    gt_text: str, raw_output: str, ignore_unreliable_articulation: bool = False
) -> NedResult:
    """Compute OMR-NED using musicdiff's full structural comparison (DetailLevel.Default).

    Component NEDs (rhythm, pitch, lift, articulation, slur) are not available in this
    mode and are returned as NaN. The overall NED uses musicdiff's own formula:
    (OMR-ED + syntax_fixes) / (numsyms_gt + numsyms_pred).

    Call _musicdiff_register_once() before entering a batch loop.
    ignore_unreliable_articulation: see "Known ground-truth reliability exceptions" above.
    """
    from musicdiff.annotation import AnnScore  # noqa: PLC0415
    from musicdiff.comparison import Comparison  # noqa: PLC0415

    gt_score, pred_score = _musicdiff_parse_scores(
        gt_text, raw_output, ignore_unreliable_articulation
    )

    ann_gt: AnnScore = AnnScore(gt_score)
    ann_pred: AnnScore = AnnScore(pred_score)

    gt_numsyms = ann_gt.notation_size()
    pred_numsyms = ann_pred.notation_size()
    syntax_fixes: int = ann_pred.num_syntax_errors_fixed

    _, omr_ed = Comparison.annotated_scores_diff(ann_pred, ann_gt)
    total_ed = omr_ed + syntax_fixes
    total_syms = gt_numsyms + pred_numsyms
    omr_ned = total_ed / total_syms if total_syms > 0 else 0.0

    nan = float("nan")
    return NedResult(
        ned=omr_ned,
        distance=total_ed,
        kern_len=gt_numsyms,
        xml_len=pred_numsyms,
        rhythm_ned=nan,
        pitch_ned=nan,
        lift_ned=nan,
        articulation_ned=nan,
        slur_ned=nan,
    )


def _musicdiff_detailed_ned_for_sample(
    gt_text: str, raw_output: str, ignore_unreliable_articulation: bool = False
) -> NedResult:
    """Compute OMR-NED with per-component breakdown using multiple musicdiff DetailLevel runs.

    Runs 5 separate comparisons to isolate component costs:
      rhythm_ned       - notes/rests only (DetailLevel.NotesAndRests); covers pitch, duration,
                         and accidental errors without any decorations
      pitch_ned        - NaN (pitch cannot be cleanly separated from rhythm within a note)
      lift_ned         - beams/flags NED, isolated from note errors
                         = (cost(NotesAndRests|Beams) - cost(NotesAndRests)) / beam_symbols
      articulation_ned - articulations NED, isolated from note errors
                         = (cost(NotesAndRests|Articulations) - cost(NotesAndRests)) / artic_symbols
      slur_ned         - slurs NED (DetailLevel.Slurs; independent of NotesAndRests)

    Slower than the plain 'musicdiff' mode due to the additional comparisons.
    Call _musicdiff_register_once() before entering a batch loop.
    ignore_unreliable_articulation: see "Known ground-truth reliability exceptions" above -
    when set, articulation_ned above is computed from scores with no articulations left on
    either side, so it will read as 0 (or NaN if artic_syms ends up 0), not a real measurement.
    """
    from musicdiff.annotation import AnnScore  # noqa: PLC0415
    from musicdiff.comparison import Comparison  # noqa: PLC0415
    from musicdiff.detaillevel import DetailLevel  # noqa: PLC0415

    gt_score, pred_score = _musicdiff_parse_scores(
        gt_text, raw_output, ignore_unreliable_articulation
    )

    def _compare(dl: int) -> tuple[int, int, int, int]:
        """Return (ed, syntax_fixes, gt_size, pred_size) for one DetailLevel."""
        ann_gt = AnnScore(gt_score, detail=dl)
        ann_pred = AnnScore(pred_score, detail=dl)
        _, ed = Comparison.annotated_scores_diff(ann_pred, ann_gt)
        return (
            ed,
            ann_pred.num_syntax_errors_fixed,
            ann_gt.notation_size(),
            ann_pred.notation_size(),
        )  # noqa: E501

    ed_full, syntax_fixes, gt_full, pred_full = _compare(DetailLevel.Default)
    total_syms = gt_full + pred_full
    ned = (ed_full + syntax_fixes) / total_syms if total_syms > 0 else 0.0

    ed_notes, _, gt_notes, pred_notes = _compare(DetailLevel.NotesAndRests)
    notes_syms = gt_notes + pred_notes
    rhythm_ned = ed_notes / notes_syms if notes_syms > 0 else 0.0

    ed_beams, _, gt_beams, pred_beams = _compare(DetailLevel.NotesAndRests | DetailLevel.Beams)
    beam_cost = ed_beams - ed_notes
    beam_syms = (gt_beams + pred_beams) - (gt_notes + pred_notes)
    lift_ned = beam_cost / beam_syms if beam_syms > 0 else 0.0

    ed_artic, _, gt_artic, pred_artic = _compare(
        DetailLevel.NotesAndRests | DetailLevel.Articulations
    )
    artic_cost = ed_artic - ed_notes
    artic_syms = (gt_artic + pred_artic) - (gt_notes + pred_notes)
    articulation_ned = artic_cost / artic_syms if artic_syms > 0 else 0.0

    ed_slurs, _, gt_slurs, pred_slurs = _compare(DetailLevel.Slurs)
    slur_syms = gt_slurs + pred_slurs
    slur_ned = ed_slurs / slur_syms if slur_syms > 0 else 0.0

    return NedResult(
        ned=ned,
        distance=ed_full + syntax_fixes,
        kern_len=gt_full,
        xml_len=pred_full,
        rhythm_ned=rhythm_ned,
        pitch_ned=float("nan"),
        lift_ned=lift_ned,
        articulation_ned=articulation_ned,
        slur_ned=slur_ned,
    )
