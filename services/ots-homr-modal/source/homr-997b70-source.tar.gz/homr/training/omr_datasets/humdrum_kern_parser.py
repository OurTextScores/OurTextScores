import copy
import re
from typing import NamedTuple

from homr.circle_of_fifths import strip_naturals
from homr.transformer.vocabulary import EncodedSymbol, empty, nonote
from training.omr_datasets.staff_merging import (
    EncodedSymbolWithPos,
    merge_upper_and_lower_staff,
)
from training.transformer.training_vocabulary import VocabularyStats, check_token_lines


class _SignatureState(NamedTuple):
    """The clef/key/time signature in force at the end of a staff's kern document.

    Carried across concatenated multi-document kern (one document per system) so a
    system's opening clef/key/time is only emitted as a token when it actually differs
    from what was already in force - not just because the document restarts.
    """

    clef: EncodedSymbol
    key: EncodedSymbol
    time: EncodedSymbol


def convert_kern_to_tokens(lines: list[str]) -> list[EncodedSymbol]:
    staffs = _merge_multiple_voices_on_the_same_staff(lines)
    merged = merge_upper_and_lower_staff(
        [
            _convert_single_staff(staff_no, staff)[0]
            for staff_no, staff in enumerate(reversed(staffs))
        ]
    )
    merged = _remove_redundant_key_changes(merged)
    merged = _fix_final_repeat_start(merged)
    merged = strip_naturals(merged)
    return merged


def convert_kern_to_parts(lines: list[str]) -> list[list[EncodedSymbol]]:
    """Return one token list per spine group for part-by-part NED comparison.

    Two-spine grand-staff scores are reversed so treble comes first, matching
    how _split_grand_staff orders MusicXML parts (staff 1 = treble first).
    All other spine counts preserve the original spine order, which music21
    also preserves in its XML output.

    Handles concatenated multi-document kern (multiple **kern...*- sections, as
    produced by datasets that store one kern document per staff system) by parsing
    each document separately and extending the corresponding parts. The clef/key/time
    signature in force is carried from one document to the next, so a system's opening
    declarations only become tokens when they are an actual change - not just because
    every system re-prints them (see _SignatureState).
    """
    docs = _split_kern_documents(lines)
    if len(docs) == 1:
        parts, _carry = _parse_kern_document(docs[0])
        return parts

    carry: list[_SignatureState] | None = None
    doc_parts_list: list[list[list[EncodedSymbol]]] = []
    for doc in docs:
        parts, carry = _parse_kern_document(doc, carry)
        doc_parts_list.append(parts)

    n_parts = max(len(p) for p in doc_parts_list)
    merged: list[list[EncodedSymbol]] = [[] for _ in range(n_parts)]
    for doc_parts in doc_parts_list:
        for i, part in enumerate(doc_parts):
            merged[i].extend(part)
    return merged


def _split_kern_documents(lines: list[str]) -> list[list[str]]:
    """Split a (possibly concatenated) kern text into individual documents."""
    docs: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        current.append(line)
        stripped = line.strip()
        if stripped and all(tok.strip() == "*-" for tok in stripped.split("\t")):
            docs.append(current)
            current = []
    if current:
        docs.append(current)
    return docs or [lines]


def _parse_kern_document(
    lines: list[str], carry: list[_SignatureState] | None = None
) -> tuple[list[list[EncodedSymbol]], list[_SignatureState]]:
    staffs = _merge_multiple_voices_on_the_same_staff(lines)
    ordered = list(reversed(staffs)) if len(staffs) == 2 else staffs
    result = []
    new_carry: list[_SignatureState] = []
    for staff_no, staff in enumerate(ordered):
        initial = carry[staff_no] if carry is not None and staff_no < len(carry) else None
        single, final_state = _convert_single_staff(staff_no, staff, initial)
        part = merge_upper_and_lower_staff([single])
        part = _remove_redundant_key_changes(part)
        part = _fix_final_repeat_start(part)
        part = strip_naturals(part)
        result.append(part)
        new_carry.append(final_state)
    return result, new_carry


def _merge_multiple_voices_on_the_same_staff(
    lines: list[str],
) -> list[list[str]]:
    """
    Merges voices into staffs.

    Humdrum kern uses special symbols: *^ and *v to split and merge voices
    """
    staff_lines: list[list[str]] = []
    spine_to_staff: list[int] = []

    for raw_line in lines:
        line = raw_line.rstrip("\n")
        if not line.strip():
            for staff in staff_lines:
                staff.append("")
            continue

        tokens = line.split("\t")

        # Initialize spines
        if all(tok.startswith("**") for tok in tokens):
            spine_to_staff = list(range(len(tokens)))
            staff_lines = [[] for _ in range(max(spine_to_staff) + 1)]
            for i in range(len(staff_lines)):
                staff_lines[i].append("**kern")
            continue

        # Split
        if "*^" in tokens:
            new_map = []
            for i, tok in enumerate(tokens):
                if tok == "*^":
                    new_map.extend([spine_to_staff[i], spine_to_staff[i]])
                else:
                    new_map.append(spine_to_staff[i])
            spine_to_staff = new_map
            continue

        # Join
        elif "*v" in tokens:
            new_map = []
            i = 0
            while i < len(tokens):
                if i + 1 < len(tokens) and tokens[i] == "*v" and tokens[i + 1] == "*v":
                    new_map.append(spine_to_staff[i])
                    i += 2
                else:
                    new_map.append(spine_to_staff[i])
                    i += 1
            spine_to_staff = new_map
            continue

        # Data line
        grouped: dict[int, list[str]] = {}
        for i, tok in enumerate(tokens):
            if i >= len(spine_to_staff):
                continue  # skip extra unexpected tokens
            s = spine_to_staff[i]
            grouped.setdefault(s, []).append(tok)
        for s, items in grouped.items():
            while len(staff_lines) <= s:
                staff_lines.append([])
            staff_lines[s].append(" ".join(items))

    return staff_lines


def _remove_redundant_key_changes(symbols: list[EncodedSymbol]) -> list[EncodedSymbol]:
    last_symbol = EncodedSymbol("")
    result = []
    for symbol in symbols:
        # Key signature was already added, this happend e.g. in
        # datasets/grandstaff/scarlatti-d/keyboard-sonatas/L348K244/min3_up_m-89-93.tokens
        # as there is a clef change for one staff and a key change for both, but the
        # key change doesn't happen in one line then
        if symbol.rhythm.startswith("keySignature") and symbol.rhythm == last_symbol.rhythm:
            continue
        result.append(symbol)
        last_symbol = symbol
    return result


def _fix_final_repeat_start(symbols: list[EncodedSymbol]) -> list[EncodedSymbol]:
    """
    If a measure ends with a repeat start then in the actual image you only see
    a barline rendered.
    """
    if len(symbols) == 0:
        return symbols
    if symbols[-1].rhythm == "repeatEndStart":
        symbols[-1].rhythm = "repeatEnd"
    if symbols[-1].rhythm == "repeatStart":
        symbols[-1].rhythm = "barline"
    return symbols


def _convert_single_staff(
    staff_no: int, lines: list[str], initial: _SignatureState | None = None
) -> tuple[list[EncodedSymbolWithPos], _SignatureState]:
    converter = HumdrumKernConverter()
    return converter.convert_humdrum_kern(staff_no, lines, initial)


class HumdrumKernConverter:
    def __init__(self) -> None:
        # Grandstaff definitions: https://link.springer.com/article/10.1007/s10032-023-00432-z#Tab1
        self.ignore_beams = ("L", "J", "K", "k")
        self.ignore_alteration_displays = ("x", "X", "i", "I", "j", "Z", "y", "Y")
        self.ignore_tie_continue = "_"
        # According to the grandstaff paper angleBracketOpen & Close stands for tieStart and tieEnd
        # but there is no tie visible
        self.angled_brackets = ("<", ">")

    def _accidental_to_lift(self, accidental: str) -> str:
        return {"-": "b", "--": "bb", "#": "#", "##": "##", "n": "N"}.get(accidental, empty)

    def _articulation_from_suffix(self, suffix: str) -> tuple[str, str]:
        for symbol in self.ignore_beams:
            suffix = suffix.replace(symbol, "")
        for symbol in self.ignore_alteration_displays:
            suffix = suffix.replace(symbol, "")
        for symbol in self.angled_brackets:
            suffix = suffix.replace(symbol, "")
        suffix = suffix.replace(self.ignore_tie_continue, "")

        if not suffix:
            return empty, empty

        slur_mapping = {
            "[": "slurStart",
            "]": "slurStop",
            "(": "slurStart",
            ")": "slurStop",
        }
        articulation_mapping = {
            ":": "arpeggiate",
            "'": "staccato",
            "`": "staccatissimo",
            "t": "trill",
            "T": "trill",
            "m": "mordent",
            "M": "trill",  # invertedMordent maps to trill in our XML parser
            "S": "turn",
            "$": "turn",
            "^": "accent",
            ";": "fermata",
        }
        articulations = []
        slurs = []
        for char in suffix:
            if char in slur_mapping:
                slurs.append(slur_mapping[char])
            elif char in articulation_mapping:
                articulations.append(articulation_mapping[char])

        if slurs and articulations:
            return str.join("_", articulations), str.join("_", slurs)
        elif slurs:
            return empty, str.join("_", slurs)
        elif articulations:
            return str.join("_", articulations), empty
        else:
            # For ruff, this case should be excluded with
            # return empty, empty in line 148
            return empty, empty

    def parse_clef(self, clef: str) -> EncodedSymbol:
        clef_name = clef.split(maxsplit=1)[0].replace("*clef", "clef_")
        defaults = {"clef_F": "clef_F4", "clef_G": "clef_G2", "clef_C": "clef_C3"}
        clef_name = defaults.get(clef_name, clef_name)
        return EncodedSymbol(clef_name, empty, empty, empty, empty)

    def parse_key_signature(self, key_signature: str) -> EncodedSymbol:
        mapping = {
            "*k[b-e-a-d-g-c-f-]": -7,
            "*k[b-e-a-d-g-c-]": -6,
            "*k[b-e-a-d-g-]": -5,
            "*k[b-e-a-d-]": -4,
            "*k[b-e-a-]": -3,
            "*k[b-e-]": -2,
            "*k[b-]": -1,
            "*k[]": 0,
            "*k[f#]": 1,
            "*k[f#c#]": 2,
            "*k[f#c#g#]": 3,
            "*k[f#c#g#d#]": 4,
            "*k[f#c#g#d#a#]": 5,
            "*k[f#c#g#d#a#e#]": 6,
            "*k[f#c#g#d#a#e#b#]": 7,
            "*kcancel": 0,
        }
        circle = mapping[key_signature.split(maxsplit=1)[0]]
        return EncodedSymbol(f"keySignature_{circle}")

    def parse_time_signature(self, ts: str) -> EncodedSymbol:
        ts_val = ts.split(maxsplit=1)[0].replace("*M", "")
        parts = ts_val.split("/")
        return EncodedSymbol(f"timeSignature/{parts[1]}")

    def parse_duration(self, dur: str, is_rest: bool = False, is_grace: bool = False) -> str:
        if not dur:
            raise ValueError("Missing duration " + dur)
        has_dot = dur.endswith(".")
        dur_val = int(dur.replace(".", ""))
        grace = "G" if is_grace else ""
        base = "rest" if is_rest else "note"
        return f"{base}_{dur_val}{grace}{'.' if has_dot else ''}"

    def kern_note_to_pitch(self, kern_note: str) -> str:
        letter = kern_note[0].upper()
        count = len(kern_note)
        return f"{letter}{3 + count}" if kern_note[0].islower() else f"{letter}{4 - count}"

    _DUR_RE = re.compile(r"[()[\]<>&/\\^~yYxXiIjZN]*(\d+\.?)")

    def _extract_dur(self, token: str) -> str | None:
        """Return the raw duration string from a kern token, or None if absent."""
        m = self._DUR_RE.match(token)
        return m.group(1) if m else None

    def parse_note_or_rest(self, token: str, default_dur: str = "4") -> EncodedSymbol:
        # Prefix: slur/tie/accent/stem/roll/alteration markers before the duration.
        # Between duration and pitch: grace note q, sforzando ^^, tuplet % ratios, etc.
        # Non-capturing group for "between" keeps group indices identical to before.
        match = re.match(
            r"[()[\]<>&/\\^~yYxXiIjZN]*(\d*\.*)(?:[^a-grA-GR#]*)([a-grA-GR]+)(--|-|n|##|#)?([^#]*)",
            token,
        )
        if not match:
            raise Exception(f"Invalid note {token}")

        dur, pitch, accidental, suffix = match[1], match[2], match[3], match[4]
        is_rest = pitch == "r"
        is_grace = "q" in token
        suffix = suffix.replace("q", "")

        rhythm_key = self.parse_duration(dur or default_dur, is_rest=is_rest, is_grace=is_grace)
        if is_rest:
            return EncodedSymbol(rhythm_key, empty, empty, empty, empty)

        lift_val = self._accidental_to_lift(accidental)
        pitch_val = self.kern_note_to_pitch(pitch)
        articulation_val, slur_val = self._articulation_from_suffix(suffix)
        return EncodedSymbol(rhythm_key, pitch_val, lift_val, articulation_val, slur_val)

    def parse_barline(self, line: str) -> list[EncodedSymbol]:
        symbol = line.split(" ", maxsplit=1)[0]
        mapping = {
            "=:|!|:": ["repeatEndStart"],
            "=": ["barline"],
            "=-": [],  # barline after clef, key and time sig
            "==:|!": ["repeatEnd"],
            "==": ["bolddoublebarline"],
            "=:|!": ["repeatEnd"],
            "=!|:": ["repeatStart"],
            "=||": ["doublebarline"],
            "=|!": ["barline"],
        }
        return [EncodedSymbol(s) for s in mapping[symbol]]

    def _get_default_clef(self, staff_no: int) -> EncodedSymbol:
        if staff_no == 0:
            return EncodedSymbol("clef_G2", empty, empty, empty, empty, "upper")
        return EncodedSymbol("clef_F4", empty, empty, empty, empty, "lower")

    def _add_line_numbers(self, lines: list[str]) -> list[tuple[int, str]]:
        """
        Control chars seem to have no specific order and must be treated
        as if we would be on the same line.
        """
        line_no = 0
        result: list[tuple[int, str]] = []
        in_control_group = True
        for line in lines:
            control_line = line.startswith("*")
            if control_line and in_control_group:
                result.append((line_no, line))
            else:
                line_no += 1
                result.append((line_no, line))
                in_control_group = control_line
        return result

    def convert_humdrum_kern(
        self, staff_no: int, lines: list[str], initial: _SignatureState | None = None
    ) -> tuple[list[EncodedSymbolWithPos], _SignatureState]:  # noqa: C901
        result: list[EncodedSymbolWithPos] = []

        prev_clef = initial.clef if initial is not None else self._get_default_clef(staff_no)
        prev_key = initial.key if initial is not None else EncodedSymbol("keySignature_0")
        prev_time = initial.time if initial is not None else EncodedSymbol("timeSignature/4")

        clef = EncodedSymbolWithPos(-10, prev_clef)
        keySignature = EncodedSymbolWithPos(-9, prev_key)
        timeSignature = EncodedSymbolWithPos(-8, prev_time)
        initial_signature_was_added = False
        for line_no, line in self._add_line_numbers(lines):
            if line.startswith("="):
                if initial_signature_was_added:
                    parsed = self.parse_barline(line)
                    result.extend([EncodedSymbolWithPos(line_no, p) for p in parsed])
            elif line.startswith("*k"):
                new_key = self.parse_key_signature(line)
                if initial_signature_was_added and new_key != keySignature.symbol:
                    result.append(EncodedSymbolWithPos(line_no, new_key))
                keySignature = EncodedSymbolWithPos(-9, new_key)
            elif line.startswith("*M"):
                new_time = self.parse_time_signature(line)
                if initial_signature_was_added and new_time != timeSignature.symbol:
                    result.append(EncodedSymbolWithPos(line_no, new_time))
                timeSignature = EncodedSymbolWithPos(-8, new_time)
            elif line.startswith("*clef"):
                new_clef = self.parse_clef(line)
                if initial_signature_was_added and new_clef != clef.symbol:
                    result.append(EncodedSymbolWithPos(line_no, new_clef))
                clef = EncodedSymbolWithPos(-10, new_clef)
            elif line.startswith("*"):
                # All other control instructions can be ignored
                pass
            else:
                if not initial_signature_was_added:
                    # Symbols can be appear in various order
                    # and duplicated (in which the latest wins). With no carried-over
                    # state (the very first document of a piece), always emit - that is
                    # the real start of the piece, regardless of whether it happens to
                    # match our internal defaults. With carried-over state (a later
                    # system in a multi-document kern file, see _SignatureState), only
                    # emit if it actually changed - a system restart re-declaring the
                    # same clef/key/time is not a real change.
                    if initial is None or clef.symbol != prev_clef:
                        result.append(clef)
                    if initial is None or keySignature.symbol != prev_key:
                        result.append(keySignature)
                    if initial is None or timeSignature.symbol != prev_time:
                        result.append(timeSignature)
                    initial_signature_was_added = True
                symbols = line.split()
                chord_dur = "4"
                first = True
                for token in symbols:
                    if token == nonote:
                        continue
                    if first:
                        extracted = self._extract_dur(token)
                        if extracted:
                            chord_dur = extracted
                        first = False
                    result.append(
                        EncodedSymbolWithPos(line_no, self.parse_note_or_rest(token, chord_dur))
                    )

        # Snapshot independent copies: the symbols above are later mutated in place
        # (e.g. merge_upper_and_lower_staff fills in symbol.position), so returning the
        # same objects would let that later mutation leak back into the carried state.
        return result, _SignatureState(
            copy.copy(clef.symbol), copy.copy(keySignature.symbol), copy.copy(timeSignature.symbol)
        )


if __name__ == "__main__":
    import glob
    import os

    from homr.simple_logging import eprint

    stats = VocabularyStats()
    files = glob.glob(os.path.join("datasets", "grandstaff", "**", "**.krn"), recursive=True)
    for file in files:
        with open(file, encoding="utf-8", errors="ignore") as f:
            tokens = convert_kern_to_tokens(f.readlines())
            check_token_lines(tokens)
            stats.add_lines(tokens)
    eprint("Stats", stats)
