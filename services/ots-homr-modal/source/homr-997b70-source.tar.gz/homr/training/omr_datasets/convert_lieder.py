# ruff: noqa: E402

import hashlib
import json
import multiprocessing
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from homr.circle_of_fifths import strip_naturals
from homr.download_utils import download_file, unzip_file
from homr.simple_logging import eprint
from homr.transformer.vocabulary import EncodedSymbol, empty
from training.omr_datasets.musescore_svg import (
    SvgMusicFile,
    SvgStaff,
    get_position_from_multiple_svg_files,
)
from training.omr_datasets.music_xml_parser import Measure, music_xml_file_to_tokens
from training.omr_datasets.notation_sidecar import write_sidecar
from training.transformer.training_vocabulary import (
    calc_ratio_of_tuplets,
    token_lines_to_str,
)

script_location = os.path.dirname(os.path.realpath(__file__))
git_root = Path(script_location).parent.parent.absolute()
dataset_root = os.path.join(git_root, "datasets")
lieder = os.path.join(dataset_root, "Lieder-main")
quartets = os.path.join(dataset_root, "StringQuartets-main")
lieder_train_index = os.path.join(lieder, "index.txt")
musescore_path = os.path.join(dataset_root, "MuseScore")


class MusicXmlPage:
    def __init__(self, voices: list[list[Measure]], number_of_measures: int = 0) -> None:
        if len(voices) > 0:
            self.number_of_measures = len(voices[0])
        else:
            self.number_of_measures = number_of_measures


def split_into_pages(voices: list[list[Measure]]) -> list[MusicXmlPage]:
    """Split voices into pages based on the new_page flag in measures.

    When a measure has new_page=True, it starts a new page.
    All voices must be synchronized - they must split at the same measure indices.

    Raises:
        ValueError: If voices have different lengths or page breaks don't align.
    """
    if not voices:
        return []

    if not voices[0]:
        return []

    # Validate all voices have the same length
    first_voice_len = len(voices[0])
    for i, voice in enumerate(voices[1:], start=1):
        if len(voice) != first_voice_len:
            raise ValueError(
                f"Voice {i} has {len(voice)} measures, but voice 0 has {first_voice_len} measures. "
                "All voices must have the same number of measures."
            )

    # Find page break positions for each voice
    voice_page_breaks: list[list[int]] = []

    for voice in voices:
        page_breaks = [0]  # Start of first page

        for measure_idx, measure in enumerate(voice):
            if hasattr(measure, "new_page") and measure.new_page and measure_idx > 0:
                page_breaks.append(measure_idx)

        page_breaks.append(len(voice))  # End position
        voice_page_breaks.append(page_breaks)

    # Validate all voices have the same page break positions
    reference_breaks = voice_page_breaks[0]
    for voice_idx, breaks in enumerate(voice_page_breaks[1:], start=1):
        if breaks != reference_breaks:
            raise ValueError(
                f"Voice {voice_idx} has page breaks at {breaks[1:-1]}, "
                f"but voice 0 has page breaks at {reference_breaks[1:-1]}. "
                "All voices must have page breaks at the same measure indices."
            )

    # Split all voices at the validated page break positions
    pages: list[MusicXmlPage] = []

    for i in range(len(reference_breaks) - 1):
        start_idx = reference_breaks[i]
        end_idx = reference_breaks[i + 1]

        # Extract measures for this page from all voices
        page_voices: list[list[Measure]] = []
        for voice in voices:
            page_voices.append(voice[start_idx:end_idx])

        pages.append(MusicXmlPage(page_voices))

    return pages


def copy_all_mscx_files(working_dir: str, dest: str) -> None:
    for root, _dirs, files in os.walk(working_dir):
        for file in files:
            if file.endswith(".mscx"):
                source = os.path.join(root, file)
                shutil.copyfile(source, os.path.join(dest, file))


def create_formats(
    source_file: str, formats: list[str], style_file: str | None = None
) -> list[dict[str, str]]:
    jobs: list[dict[str, str]] = []

    # sq8940236: MuseScore seems to hang up
    # lc5001945: nested tuplet, not good for training
    # lc6209608, lc6236149: empty&invisible staff in the very first system
    # lc6162644: irregular staff in the last svg page
    # lc6420897: page 9, measure 49 and 50 are hard to read
    # lc6196804: lc6196804-3-4.tokens has a strange `arpeggiate_breathMark`,
    # which will cause error in training, skip for now
    files_with_known_issues = [
        "sq8940236",
        "lc5001945",
        "lc6162644",
        "lc6209608",
        "lc6236149",
        "lc6420897",
        "lc6196804",
    ]
    if any(issue in source_file for issue in files_with_known_issues):
        return jobs
    for target_format in formats:
        dirname = os.path.dirname(source_file)
        basename = os.path.basename(source_file)
        out_name = dirname + "/" + basename.replace(".mscx", f".{target_format}")
        out_name_alt = dirname + "/" + basename.replace(".mscx", f"-1.{target_format}")
        if os.path.exists(out_name) or os.path.exists(out_name_alt):
            eprint(out_name, "already exists")
            continue
        job = {
            "in": source_file,
            "out": out_name,
        }
        if style_file is not None:
            job["style"] = style_file
        jobs.append(job)
    return jobs


# Every Lieder page is rendered by MuseScore with its default "Leland" engraving font,
# so the model only ever sees one glyph vocabulary for noteheads/clefs/accidentals/etc.
# MuseScore ships several other SMuFL-compliant engraving fonts (selectable in the app
# under Format > Style > Score > Musical Symbols, backed by a swappable <musicalSymbolFont>
# style setting); rotating through them per piece costs nothing at render time and gives
# the model exposure to multiple glyph "handwritings" without needing a different dataset
# or renderer. This only varies glyph shapes, not MuseScore's own layout/spacing engine -
# so it doesn't substitute for training on genuinely different renderers (Primus,
# grandstaff), just cheaply widens the glyph diversity within Lieder itself.
_MUSIC_FONTS = ["Leland", "Bravura", "Petaluma", "MuseJazz", "Gonville"]
_music_font_style_dir = os.path.join(dataset_root, "MuseScoreStyles")


def _music_font_style_file(font: str) -> str:
    return os.path.join(_music_font_style_dir, f"{font.replace(' ', '_')}.mss")


def _ensure_music_font_style_files() -> None:
    """
    Writes one minimal .mss style file per font in _MUSIC_FONTS (skipping ones that
    already exist), each just pointing MuseScore's musical-symbol and musical-text
    fonts at a single named font pair - MuseScore fills in every other style default.
    The "<Font> Text" naming for the paired text font mirrors the font-pair names
    MuseScore itself uses for its bundled fonts.
    """
    os.makedirs(_music_font_style_dir, exist_ok=True)
    for font in _MUSIC_FONTS:
        path = _music_font_style_file(font)
        if os.path.exists(path):
            continue
        content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<museScore version="4.00">\n'
            "  <Style>\n"
            f"    <musicalSymbolFont>{font}</musicalSymbolFont>\n"
            f"    <musicalTextFont>{font} Text</musicalTextFont>\n"
            "  </Style>\n"
            "</museScore>\n"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


def _music_font_for_file(source_file: str) -> str:
    """
    Deterministic per-piece font choice (stable across reruns/partial recreates, so a
    piece doesn't silently re-render with a different font the next time this is run)
    based on a hash of the piece's own filename, not path or run order.
    """
    stem = os.path.basename(source_file).split(".")[0]
    index = int(hashlib.sha256(stem.encode()).hexdigest(), 16) % len(_MUSIC_FONTS)
    return _MUSIC_FONTS[index]


def _make_staff_visible(mscx_file: str) -> None:
    """
    When rendering SVG, MuseScore can hide empty staff.
    This will cause problem in SvgMusicFile.merge_voice_with_next_one(), because the merge procedure
    assumes that all staffs are visible and deals with the staff one by one.

    To avoid hiding empty staff, we need to change the following 3 settings:
      * the global setting: <hideEmptyStaves>1</hideEmptyStaves>
      * the per-staff setting: <hideWhenEmpty>1</hideWhenEmpty>
      * <cutaway>1</cutaway>: this hides part of the staff, e.g. some empty measures.

    Note: unfortunatelly, this does not cover every case.
    lc6236149, lc6209608 still fails, so we just skip them.
    """
    with open(mscx_file, encoding="utf-8") as f:
        content = f.read()

    new_content = re.sub(
        r"<hideEmptyStaves>1</hideEmptyStaves>",
        "<hideEmptyStaves>0</hideEmptyStaves>",
        content,
    )
    new_content = re.sub(
        r"<hideWhenEmpty>1</hideWhenEmpty>",
        "<hideWhenEmpty>0</hideWhenEmpty>",
        new_content,
    )
    new_content = re.sub(
        r"<cutaway>1</cutaway>",
        "<cutaway>0</cutaway>",
        new_content,
    )

    if new_content != content:
        with open(mscx_file, "w", encoding="utf-8") as f:
            f.write(new_content)


def _reset_note_positions(mscx_file: str) -> None:
    """
    A manually-dragged notehead in MuseScore leaves a <pos x=".." y=".."/> override
    as the first child of its <Note> element, which shifts where it renders without
    touching its <pitch>. This is rare (~0.015% of notes dataset-wide) but when it
    happens, the rendered position can silently disagree with the note's own pitch -
    e.g. in lc4926375 a repeated E5 renders on the D5 line because of a y="0.5" (one
    diatonic step) override, so the exported image shows a different note than the
    label says.

    <pos> is also used pervasively elsewhere in this format for unrelated, legitimate
    purposes - slur/tie curve control points (nested under <Note><Tie><SlurSegment>),
    augmentation-dot offsets (<Note><NoteDot>), staff text, tempo marks, stems - so
    this only strips a <pos> that is directly the first thing inside <Note>, never one
    nested deeper. MuseScore also serializes an empty element as either a self-closing
    tag or a separate open/close pair depending on context, so both forms are matched.
    """
    with open(mscx_file, encoding="utf-8") as f:
        content = f.read()

    new_content = re.sub(
        r"(<Note>\s*)<pos\b[^>]*(?:/>|>\s*</pos>)\s*",
        r"\1",
        content,
    )

    if new_content != content:
        with open(mscx_file, "w", encoding="utf-8") as f:
            f.write(new_content)


def _create_musicxml_and_svg_files() -> None:
    dest = os.path.join(lieder, "flat")
    os.makedirs(dest, exist_ok=True)
    copy_all_mscx_files(os.path.join(lieder, "scores"), dest)

    mscx_files = list(Path(dest).rglob("*.mscx"))

    MuseScore = os.path.join(dataset_root, "MuseScore")

    _ensure_music_font_style_files()

    all_jobs = []

    for file in mscx_files:
        _make_staff_visible(str(file))
        _reset_note_positions(str(file))
        style_file = _music_font_style_file(_music_font_for_file(str(file)))
        jobs = create_formats(str(file), ["musicxml", "svg"], style_file)
        all_jobs.extend(jobs)

    if len(all_jobs) == 0:
        eprint("All musicxml were already created, going on with the next step")
        return

    eprint("Starting with", len(all_jobs), "jobs")

    BATCH_SIZE = 50
    failed_files: list[str] = []

    batches = [all_jobs[i : i + BATCH_SIZE] for i in range(0, len(all_jobs), BATCH_SIZE)]

    for batch_idx, batch in enumerate(batches):
        eprint(f"Processing batch {batch_idx + 1}/{len(batches)} ({len(batch)} jobs)")

        with open("job.json", "w") as f:
            json.dump(batch, f)

        if os.system(MuseScore + " --force -j job.json") == 0:  # noqa: S605
            os.remove("job.json")
            continue

        env = os.environ.copy()
        # No need to run GUI, so we can use offscreen backend
        env["QT_QUICK_BACKEND"] = "software"
        env["QT_QPA_PLATFORM"] = "offscreen"

        # Batch failed - retry each job individually
        eprint(f"Batch {batch_idx + 1} failed, retrying individually")
        os.remove("job.json")

        for job in batch:
            with open("job.json", "w") as f:
                json.dump([job], f)

            if os.system(MuseScore + " --force -j job.json") != 0:  # noqa: S605
                eprint("Failed:", job["in"])
                failed_files.append(job["in"])

            if os.path.exists("job.json"):
                os.remove("job.json")

    if failed_files:
        eprint(f"\nMuseScore export finished with {len(failed_files)} failed file(s):")
        for path in failed_files:
            eprint(" ", path)
    else:
        eprint("MuseScore export completed with no failures.")


def write_text_to_file(text: str, path: str) -> None:
    with open(path, "w") as f:
        f.write(text)


class MeasureCutter:
    def __init__(self, voice: list[Measure]) -> None:
        self.voice = voice
        self.number_of_staffs = _count_staffs(voice)
        if self.number_of_staffs == 1:
            self.clefs = [EncodedSymbol("clef_G2", empty, empty, empty, empty, "upper")]
        else:
            self.clefs = [
                EncodedSymbol("clef_G2", empty, empty, empty, empty, "upper"),
                EncodedSymbol("clef_F4", empty, empty, empty, empty, "lower"),
            ]
        self.key = EncodedSymbol("keySignature_0")
        self.time = EncodedSymbol("timeSignature/4")
        #: The numerator token that precedes `self.time`, carried separately.  It has
        #: to be: `"timeSignature" in symbol.rhythm` matches `timeSignatureBeats_3` as
        #: well as `timeSignature/4`, and since the numerator is emitted first the
        #: denominator overwrote it a moment later - so every restatement carried
        #: across a slice boundary lost its numerator. That left 77 numerators against
        #: 416 time signatures in the corpus, five times less metre supervision than
        #: the labels actually contain.
        self.time_beats: EncodedSymbol | None = None

    def _position_to_staff_no(self, symbol: EncodedSymbol) -> int:
        if symbol.position == "lower":
            return 1
        return 0

    def extract_measures(
        self, count: int, always_include_time: bool = False
    ) -> list[EncodedSymbol]:
        clefs = self.clefs.copy()
        key = self.key
        time = self.time
        time_beats = self.time_beats
        # Lieder pages are crops of one continuously rendered score, so a courtesy time
        # signature is only visible where the source XML actually redeclares it. pdmx and
        # musetrainer windows are each re-rendered standalone (see generate_xml), and that
        # renderer always draws a time signature on a fresh score - so those callers pass
        # always_include_time=True to keep the label in sync with the image.
        has_time = always_include_time
        result: list[EncodedSymbol] = []
        for i in range(count):
            selected_measure = self.voice.pop(0)
            is_first_measure = i == 0
            first_measure_before_any_non_key_or_clef = is_first_measure
            measure_result: list[EncodedSymbol] = []
            for symbol in selected_measure:
                if "clef" in symbol.rhythm:
                    self.clefs[self._position_to_staff_no(symbol)] = symbol
                    if not first_measure_before_any_non_key_or_clef:
                        measure_result.append(symbol)
                    else:
                        clefs[self._position_to_staff_no(symbol)] = symbol
                elif "keySignature" in symbol.rhythm:
                    self.key = symbol
                    if not first_measure_before_any_non_key_or_clef:
                        measure_result.append(symbol)
                    else:
                        key = symbol
                elif "chord" in symbol.rhythm:
                    if not first_measure_before_any_non_key_or_clef:
                        measure_result.append(symbol)
                elif symbol.rhythm.startswith("timeSignatureBeats"):
                    # Checked before the denominator: the prefix test below would match
                    # this token too, and the numerator must not be mistaken for it.
                    self.time_beats = symbol
                    if not first_measure_before_any_non_key_or_clef:
                        measure_result.append(symbol)
                    else:
                        time_beats = symbol
                elif "timeSignature" in symbol.rhythm:
                    self.time = symbol
                    if not first_measure_before_any_non_key_or_clef:
                        measure_result.append(symbol)
                    else:
                        has_time = True
                        time = symbol
                else:
                    first_measure_before_any_non_key_or_clef = False
                    measure_result.append(symbol)

            if is_first_measure:
                if has_time:
                    measure_result.insert(0, time)
                    # The numerator goes back in front of its denominator, so a
                    # restated signature says 3/4 rather than an unqualified "/4".
                    if time_beats is not None:
                        measure_result.insert(0, time_beats)
                measure_result.insert(0, key)
                for j, clef in enumerate(reversed(clefs)):
                    if j > 0:
                        measure_result.insert(0, EncodedSymbol("chord"))
                    measure_result.insert(0, clef)
            result.extend(measure_result)
        return result


def contains_only_supported_clefs(symbols: list[EncodedSymbol]) -> float:
    for symbol in symbols:
        if symbol.rhythm.startswith("clef_percussion"):
            return False
    return True


def _split_file_into_staffs(
    number_of_voices: int,
    svg_file: SvgMusicFile,
    splitter: list[MeasureCutter],
    just_token_files: bool,
    fail_if_image_is_missing: bool,
) -> list[str]:
    result: list[str] = []
    png_file = svg_file.filename.replace(".svg", ".png")
    image = None
    if not just_token_files:
        target_width = 1400
        scale = target_width / svg_file.width
        subprocess.run(  # noqa: S603
            [  # noqa: S607
                "rsvg-convert",
                "-w",
                "1400",
                "-o",
                png_file,
                svg_file.filename,
            ],
            check=True,
        )
        pil_img = Image.open(png_file).convert("L")
        image = np.array(pil_img)
    # alternate through voices
    staffs: list[SvgStaff] = sorted(svg_file.staffs.copy(), key=lambda x: x.y)
    current_voice = 0
    staff_number = 0
    while len(staffs) > 0:
        staff_number += 1
        total_staff_area = staffs.pop(0)
        measures = splitter[current_voice]
        staff_image_file_name = png_file.replace(".png", f"-{staff_number}.png")
        if not just_token_files:
            y_offset = 50
            x_offset_right = 10
            x_offset_left = 40
            x = total_staff_area.x - x_offset_left
            y = total_staff_area.y - y_offset
            width = total_staff_area.width + x_offset_right + x_offset_left
            height = total_staff_area.height + 2 * y_offset
            x = int(x * scale)
            y = int(y * scale)
            width = int(width * scale)
            height = int(height * scale)

            staff_image = image[y : y + height, x : x + width]  # type: ignore
            cv2.imwrite(staff_image_file_name, staff_image)
        elif not os.path.exists(staff_image_file_name) and fail_if_image_is_missing:
            raise ValueError(f"File {staff_image_file_name} not found")

        token_file_name = png_file.replace(".png", f"-{staff_number}.tokens")
        selected_measures: list[EncodedSymbol] = measures.extract_measures(
            total_staff_area.number_of_measures
        )

        if calc_ratio_of_tuplets(selected_measures) <= 0.2 and contains_only_supported_clefs(
            selected_measures
        ):
            selected_measures = strip_naturals(selected_measures)
            tokens_content = token_lines_to_str(selected_measures)
            write_text_to_file(tokens_content, token_file_name)
            # Lieder renders its SVG and its MusicXML from the same source .mscx, so the
            # staff image shows the score's own engraving and beam, stem and slur labels
            # taken from that MusicXML describe the picture. That is not true of every
            # corpus - see 27.25 - so the sidecar is written here deliberately rather than
            # by every converter that happens to use this parser.
            write_sidecar(token_file_name, selected_measures)
            result.append(
                str(Path(staff_image_file_name).relative_to(git_root))
                + ","
                + str(Path(token_file_name).relative_to(git_root))
                + "\n"
            )
        current_voice = (current_voice + 1) % number_of_voices

    if image is not None:
        del image

    return result


def _leading_clefs(measure: Measure) -> list[EncodedSymbol]:
    # The clefs of a measure always precede its notes/rests, but other preamble symbols
    # (e.g. repeatStart on the very first measure) can come before them, so scan rather
    # than assume fixed indices.
    clefs = []
    for symbol in measure:
        if symbol.rhythm.startswith(("note", "rest")):
            break
        if symbol.rhythm.startswith("clef"):
            clefs.append(symbol)
    return clefs


def _count_staffs(voice: list[Measure]) -> int:
    if len(voice) == 0:
        return 0
    clefs = _leading_clefs(voice[0])
    if len(clefs) == 0:
        return 0
    return 2 if len(clefs) >= 2 else 1


def is_grandstaff(voice: list[Measure]) -> bool:
    if len(voice) == 0:
        return False
    return len(_leading_clefs(voice[0])) >= 2


def get_svg_voice_count(voice: list[Measure]) -> int:
    """
    The concepts get confusing here: The SVG treats
    a grandstaff as two voices. While in MusicXML it's a
    single voice.
    """
    if is_grandstaff(voice):
        return 2
    return 1


def convert_xml_and_svg_file(
    file: Path, just_token_files: bool, fail_if_image_is_missing: bool = True
) -> list[str]:
    try:
        voices = music_xml_file_to_tokens(str(file))
        splitter = [MeasureCutter(v) for v in voices]
        pages = split_into_pages(voices)
        svg_files = get_position_from_multiple_svg_files(str(file))
        number_of_voices = sum([get_svg_voice_count(voice) for voice in voices])
        for voice_idx, voice in enumerate(voices):
            if is_grandstaff(voice):
                for svg_file in svg_files:
                    svg_file.merge_voice_with_next_one(voice_idx, number_of_voices)
                number_of_voices -= 1

        result: list[str] = []
        assert len(pages) == len(svg_files)  # noqa: S101

        for i, page in enumerate(pages):
            svg_file = svg_files[i]
            number_of_measures_per_voice_svg = svg_file.number_of_measures / number_of_voices
            if page.number_of_measures != number_of_measures_per_voice_svg:
                eprint(
                    file,
                    "Page",
                    i + 1,
                    "INFO: Number of measures in SVG files",
                    number_of_measures_per_voice_svg,
                    "does not match number of measures in XML",
                    page.number_of_measures,
                )
                # Remove the measures from the cutter
                for cutter in splitter:
                    cutter.extract_measures(page.number_of_measures)
                continue
            result.extend(
                _split_file_into_staffs(
                    number_of_voices, svg_file, splitter, just_token_files, fail_if_image_is_missing
                )
            )
        return result

    except Exception as e:
        eprint("Error while processing", file, e)
        return []


def _convert_file_only_token(path: Path) -> list[str]:
    return convert_xml_and_svg_file(path, True)


def _convert_token_and_image(path: Path) -> list[str]:
    return convert_xml_and_svg_file(path, False)


def convert_lieder(only_recreate_token_files: bool = False) -> None:
    if platform.system() == "Windows":
        eprint("Transformer training is only implemented for Linux")
        eprint("Feel free to submit a PR to support Windows")
        eprint("Running MuseScore with the -j parameter on Windows doesn't work")
        eprint("https://github.com/musescore/MuseScore/issues/16221")
        sys.exit(1)

    if not os.path.exists(musescore_path):
        eprint("Downloading MuseScore from https://musescore.org/")
        download_file(
            "https://github.com/musescore/MuseScore/releases/download/v4.6.5/MuseScore-Studio-4.6.5.253511702-x86_64.AppImage",
            musescore_path,
        )

        perms = (
            stat.S_IRUSR
            | stat.S_IWUSR
            | stat.S_IXUSR
            | stat.S_IRGRP
            | stat.S_IXGRP
            | stat.S_IROTH
            | stat.S_IXOTH
        )

        os.chmod(musescore_path, perms)  # chmod 755

    if not os.path.exists(lieder):
        eprint("Downloading Lieder from https://github.com/OpenScore/Lieder")
        lieder_archive = os.path.join(dataset_root, "Lieder.zip")
        download_file(
            "https://github.com/OpenScore/Lieder/archive/refs/heads/main.zip", lieder_archive
        )
        unzip_file(lieder_archive, dataset_root)

        eprint("Downloading StringQuartets from https://github.com/OpenScore/StringQuartets")
        quartets_archive = os.path.join(dataset_root, "StringQuartets.zip")
        download_file(
            "https://github.com/OpenScore/StringQuartets/archive/refs/heads/main.zip",
            quartets_archive,
        )
        unzip_file(quartets_archive, dataset_root)
        shutil.copytree(
            os.path.join(quartets, "scores"), os.path.join(lieder, "scores"), dirs_exist_ok=True
        )

    eprint("Indexing Lieder dataset, this can up to several hours.")
    _create_musicxml_and_svg_files()
    music_xml_files = list(Path(os.path.join(lieder, "flat")).rglob("*.musicxml"))
    with open(lieder_train_index, "w") as f:
        file_number = 0
        skipped_files = 0
        with multiprocessing.Pool(processes=8, maxtasksperchild=2) as p:
            for result in p.imap_unordered(
                (
                    _convert_file_only_token
                    if only_recreate_token_files
                    else _convert_token_and_image
                ),
                music_xml_files,
            ):
                if len(result) > 0:
                    for line in result:
                        f.write(line)
                    f.flush()
                else:
                    skipped_files += 1
                file_number += 1
                if file_number % 10 == 0:
                    eprint(
                        f"Processed {file_number}/{len(music_xml_files)} files,",
                        f"skipped {skipped_files} files",
                    )
    eprint("Done indexing")


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")
    only_recreate_token_files = False
    if "--only-tokens" in sys.argv:
        only_recreate_token_files = True
    elif len(sys.argv) > 1:
        eprint(str.join("", _convert_token_and_image(Path(sys.argv[1]))))
        sys.exit(0)
    convert_lieder(only_recreate_token_files)
